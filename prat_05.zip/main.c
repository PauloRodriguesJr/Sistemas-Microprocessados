/* ----------------------------------------------------------------------------
 UFABC - Disciplina Sistemas Microprocessados - SuP - 2018.10
 Programa:  Prat_05
 Autor:     Joao Ranhel
 Descricao: conversor ADC + Dec 7seg + Serial 74HC595 + Display 4x7seg
 Usa:
 a) PC13 - pino 13 da GPIOC   (ON enquanto esta' CONVERTENDO)
 b) PC14 - dado convertido e display mostrando val em milivolts
 c) PB13 - pino 13 da GPIOB   (SDATA - bit de dado serializado p/ hc595)
 d) PB1  - pino 1 da GPIOB    (SCK - clock para serializar dado no hc595)
 e) PB0  - pino 0 da GPIOB    (RCK - register clock p/ salvar dado no hc595)
 f) PA0 - entrada anal�gica para conversor ADC
MSByte = QA=dig1, QB=dig2, QC=dig3, QD=dig4
LSByte = QH=segA, ... QB=segG, QA=decimal point

/  --------------------------------------------------------------------------*/

#include "stm32f10x.h"
#include "stm32f1xx_it.h"      // prots serv interrupt (ISR, em stm32f1xx_it.c)
#include "prat_05_funcoes.h"   // header do arqv das funcoes do programa

#define FREQ_TICK 1000         // frequencia do tick = 1000 Hz (1ms)
#define DELAY_VARRE  7         // inc varredura a cada 7 ms (~142 Hz)
#define DIGITO_APAGADO 0x10    // kte valor p/ apagar um d�gito no display

// --------------------------  INI PROG MAIN ----------------------------------
int main(void)
{
  // fun��es mudadas para o arquivo "funcoes.c" para melhor organizar o projeto
  setup_RCC();                         // ini: habilitar CLKs dos perif�ricos
  setup_GPIOs();                       // setup GPIOs interface LEDs
  setup_INT_externa();                 // setup Interrupcao externa
  setup_ADC_conv();                    // setup do conversor ADC
  setup_systick(FREQ_TICK);            // set timers p/ 1 ms  (1000 Hz)
  reset_pin_GPIOs();                   // garante pinos GPIOs inicializados
  reset_modo_oper();                   // zera var modo_oper

  // vars e flags de controle do programa no superloop...
  int
  milADC = 0,                          // ini decimo de seg
  cenADC = 0,                          // ini unidade de seg
  decADC = 0,                          // ini dezena de seg
  uniADC = 0;                          // ini unidade de minuto

  int16_t
  val7seg = 0x00FF,                    // inicia 7-seg com 0xF (tudo apagado)
  serial_data = 0x01FF,                // dado a serializar (dig | val7seg)
  val_adc = 0;                         // valor lido no ADC

  uint32_t miliVolt = 0x0,             // val adc convertido p/ miliVolts
  tIN_varre = 0;                       // registra tempo �ltima varredura

  // var de estado que controla a varredura (qual display � mostrado)
  static enum {DIG_UNI, DIG_DEC, DIG_CENS, DIG_MILS} sttVARRE=DIG_MILS;

  // entra no loop infinito
  while (1)
  {
  // tarefa #1: se (modo_oper=1) faz uma convers�o ADC
	if (get_modo_oper()==1)
    {
	  GPIO_WriteBit(GPIOC, GPIO_Pin_14, Bit_RESET);  // apaga o LED PC14
      GPIO_WriteBit(GPIOC, GPIO_Pin_13, Bit_RESET);  // liga o LED PC13
      // dispara por software uma convers�o ADC
	  ADC_SoftwareStartConvCmd(ADC1, ENABLE);    // habilita convers�o ADC1
	  // espera que a convers�o termine (polling)
	  while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET ) {}
      //if (ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC))
	  //{
        val_adc = ADC_GetConversionValue(ADC1);  // l� �ltimo valor convertido
	    ADC_ClearFlag(ADC1, ADC_FLAG_EOC);       // limpa flag no fim convers�o
	    // ADC1->SR = ~(uint32_t)ADC_FLAG_EOC;   // limpa flag diretamente
	 // }
      miliVolt = val_adc*3300/4095;              // converte p/ mili Volts
      uniADC = miliVolt/1000;                    // define valor unidade V
      decADC = (miliVolt-uniADC*1000)/100;       // d�cimo de V
      cenADC = (miliVolt-uniADC*1000-decADC*100)/10;      // cent�simo V
      milADC = miliVolt-uniADC*1000-decADC*100-cenADC*10; // mil�simo V
      reset_modo_oper();                         // zera var modo_oper
      GPIO_WriteBit(GPIOC, GPIO_Pin_13, Bit_SET);// apaga o LED PC13
  	  GPIO_WriteBit(GPIOC, GPIO_Pin_14, Bit_SET);// liga o LED PC14
    }  // fim da tarefa #1 (convers�o ADC se modo=1)

  // tarefa #2 FAZ SEMPRE: qdo milis() > DELAY_VARRE ms, desde a �ltima mudan�a
    if (milis()-tIN_varre > DELAY_VARRE )        // se ++0,1s atualiza o display
    {
      switch(sttVARRE)                 // teste e escolha de qual DIG vai varrer
      {
      case DIG_MILS:
  	    {
		    sttVARRE = DIG_CENS;       // ajusta p/ prox digito
			serial_data = 0x0001;      // display #1
			val7seg = conv_7_seg(milADC);
			break;
		}
      case DIG_CENS:
        {
          sttVARRE = DIG_DEC;          // ajusta p/ prox digito
		  serial_data = 0x00002;       // display #2
		  if(cenADC>0 || decADC>0 || uniADC>0)
		  {
		    val7seg = conv_7_seg(cenADC);
		  } else {
			val7seg = conv_7_seg(DIGITO_APAGADO);
		  }
		  break;
		}
      case DIG_DEC:
    	{
		  sttVARRE = DIG_UNI;        // ajusta p/ prox digito
          serial_data = 0x0004;      // display #3
          if(decADC>0 || uniADC>0)
          {
            val7seg = conv_7_seg(decADC);
          } else {
            val7seg = conv_7_seg(DIGITO_APAGADO);
          }
          break;
		}
      case DIG_UNI:
    	{
          sttVARRE = DIG_MILS;       // ajusta p/ prox digito
          serial_data = 0x0008;      // display #3
          if(uniADC>0)
          {
            val7seg = conv_7_seg(uniADC);
            val7seg &=0x7FFF;        // liga o ponto decimal
          } else {
            val7seg = conv_7_seg(DIGITO_APAGADO);
          }
          break;
		}
      }
      tIN_varre = milis();             // tmp atual em que fez essa varredura
      serial_data |= val7seg;          // OR com val7seg = dado a serializar
      serializar(serial_data);         // serializa dado p/74HC595 (shift reg)
    }  // -- fim da tarefa #2, rotina que faz de varredura do display
  }    // -- fim do loop infinito
}      // ------------------------  FIM PROG MAIN ---------------------------
